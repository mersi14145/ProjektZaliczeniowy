var searchData=
[
  ['danewejsciowe_0',['daneWejsciowe',['../graf_8h.html#ad06d2c2d4549c4dee2fcbce190e557a1',1,'graf.h']]]
];
