var graf_8h =
[
    [ "Graf", "graf_8h.html#a590d40734896bdfaa25a87975c5c7d5d", null ],
    [ "daneWejsciowe", "graf_8h.html#ad06d2c2d4549c4dee2fcbce190e557a1", null ]
];